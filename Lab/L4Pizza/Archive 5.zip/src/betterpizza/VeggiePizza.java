package betterpizza;

import java.util.Map;

import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

public class VeggiePizza implements ObservablePizza {

  protected Size size;
  protected Crust crust;
  protected Map<ToppingName, ToppingPortion> toppings;

  protected VeggiePizza(Size size, Crust crust, Map<ToppingName, ToppingPortion> toppings) throws
          IllegalArgumentException {
    if (crust == null) {
      throw new IllegalArgumentException(String.format("Pizza size not specified"));
    }
    this.crust = crust;
    if (size == null) {
      throw new IllegalArgumentException(String.format("Pizza crust type not specified"));
    }
    this.size = size;
    this.toppings = toppings;
  }

  @Override
  public double cost() {
    return 0;
  }

  @Override
  public ToppingPortion hasTopping(ToppingName name) {
    return null;
  }

  @Override
  public ObservablePizza build() { return new VeggiePizza.VeggiePizzaBuilder().build(); }
  static public class VeggiePizzaBuilder extends PizzaBuilder<VeggiePizzaBuilder> {

    @Override
    public ObservablePizza build() throws IllegalStateException {
      this.addTopping(ToppingName.Cheese, ToppingPortion.Full);
      this.addTopping(ToppingName.Sauce, ToppingPortion.Full);
      this.addTopping(ToppingName.BlackOlive, ToppingPortion.Full);
      this.addTopping(ToppingName.GreenPepper, ToppingPortion.Full);
      this.addTopping(ToppingName.Onion, ToppingPortion.Full);
      this.addTopping(ToppingName.Jalapeno, ToppingPortion.Full);
      this.addTopping(ToppingName.Tomato, ToppingPortion.Full);
      return new VeggiePizza(size, crust, toppings);
    }

    @Override
    protected VeggiePizzaBuilder returnBuilder() {
      return this;
    }

    @Override
    public ObservablePizza noCheese() {
      this.addTopping(ToppingName.Sauce, ToppingPortion.Full);
      this.addTopping(ToppingName.BlackOlive, ToppingPortion.Full);
      this.addTopping(ToppingName.GreenPepper, ToppingPortion.Full);
      this.addTopping(ToppingName.Onion, ToppingPortion.Full);
      this.addTopping(ToppingName.Jalapeno, ToppingPortion.Full);
      this.addTopping(ToppingName.Tomato, ToppingPortion.Full);
      return new VeggiePizza(size, crust, toppings);
    }

    @Override
    public ObservablePizza leftHalfCheese() {
      this.addTopping(ToppingName.Sauce, ToppingPortion.Full);
      this.addTopping(ToppingName.Cheese, ToppingPortion.LeftHalf);
      this.addTopping(ToppingName.BlackOlive, ToppingPortion.Full);
      this.addTopping(ToppingName.GreenPepper, ToppingPortion.Full);
      this.addTopping(ToppingName.Onion, ToppingPortion.Full);
      this.addTopping(ToppingName.Jalapeno, ToppingPortion.Full);
      this.addTopping(ToppingName.Tomato, ToppingPortion.Full);
      return new VeggiePizza(size, crust, toppings);
    }

    @Override
    public ObservablePizza rightHalfCheese() {
      this.toppings.put(ToppingName.Sauce, ToppingPortion.Full);
      this.toppings.put(ToppingName.Cheese, ToppingPortion.RightHalf);
      this.toppings.put(ToppingName.BlackOlive, ToppingPortion.Full);
      this.toppings.put(ToppingName.GreenPepper, ToppingPortion.Full);
      this.toppings.put(ToppingName.Onion, ToppingPortion.Full);
      this.toppings.put(ToppingName.Jalapeno, ToppingPortion.Full);
      this.toppings.put(ToppingName.Tomato, ToppingPortion.Full);
      return new VeggiePizza(size, crust, toppings);
    }

    @Override
    public ObservablePizza noJalapeno() {
      this.toppings.put(ToppingName.Sauce, ToppingPortion.Full);
      this.toppings.put(ToppingName.Cheese, ToppingPortion.Full);
      this.toppings.put(ToppingName.BlackOlive, ToppingPortion.Full);
      this.toppings.put(ToppingName.GreenPepper, ToppingPortion.Full);
      this.toppings.put(ToppingName.Onion, ToppingPortion.Full);
      this.toppings.put(ToppingName.Tomato, ToppingPortion.Full);
      return new VeggiePizza(size, crust, toppings);
    }

    @Override
    public ObservablePizza noTomato() {
      this.toppings.put(ToppingName.Sauce, ToppingPortion.Full);
      this.toppings.put(ToppingName.Cheese, ToppingPortion.Full);
      this.toppings.put(ToppingName.BlackOlive, ToppingPortion.Full);
      this.toppings.put(ToppingName.GreenPepper, ToppingPortion.Full);
      this.toppings.put(ToppingName.Onion, ToppingPortion.Full);
      this.toppings.put(ToppingName.Jalapeno, ToppingPortion.Full);
      return new VeggiePizza(size, crust, toppings);
    }
  }
}
