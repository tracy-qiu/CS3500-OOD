package betterpizza;

import java.util.Map;

import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

public class CheesePizza implements ObservablePizza {

  protected Crust crust;
  protected Size size;
  protected Map<ToppingName, ToppingPortion> toppings;

  protected CheesePizza(Size size, Crust crust, Map<ToppingName, ToppingPortion> toppings) throws
          IllegalArgumentException {
    if (crust == null) {
      throw new IllegalArgumentException(String.format("Pizza size not specified"));
    }
    this.crust = crust;
    if (size == null) {
      throw new IllegalArgumentException(String.format("Pizza crust type not specified"));
    }
    this.size = size;
    this.toppings = toppings;
  }

  @Override
  public double cost() {
    return 0;
  }

  @Override
  public ToppingPortion hasTopping(ToppingName name) {
    return null;
  }

  @Override
  public ObservablePizza build() { return new CheesePizza.CheesePizzaBuilder().build(); }
  static public class CheesePizzaBuilder extends PizzaBuilder<CheesePizzaBuilder> {

    @Override
    public ObservablePizza build() throws IllegalStateException {
      this.toppings.put(ToppingName.Sauce, ToppingPortion.Full);
      this.toppings.put(ToppingName.Cheese, ToppingPortion.Full);
      return new CheesePizza(size, crust, toppings);
    }

    @Override
    protected CheesePizzaBuilder returnBuilder() {
      return this;
    }

    @Override
    public ObservablePizza noCheese() {
      this.toppings.put(ToppingName.Sauce, ToppingPortion.Full);
      return new CheesePizza(size, crust, toppings);
    }

    @Override
    public ObservablePizza leftHalfCheese() {
      this.toppings.put(ToppingName.Sauce, ToppingPortion.Full);
      this.toppings.put(ToppingName.Cheese, ToppingPortion.LeftHalf);
      return new CheesePizza(size, crust, toppings);
    }

    @Override
    public ObservablePizza rightHalfCheese() {
      this.toppings.put(ToppingName.Sauce, ToppingPortion.Full);
      this.toppings.put(ToppingName.Cheese, ToppingPortion.RightHalf);
      return new CheesePizza(size, crust, toppings);
    }

    @Override
    public ObservablePizza noJalapeno() {
      return this.build();
    }

    @Override
    public ObservablePizza noTomato() {
      return this.build();
    }
  }
}
