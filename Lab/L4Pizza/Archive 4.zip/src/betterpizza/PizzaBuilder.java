package betterpizza;

import java.util.HashMap;
import java.util.Map;

import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

public abstract class PizzaBuilder<T> {

  protected Crust crust;
  protected Size size;

  protected Map<ToppingName, ToppingPortion> toppings;

  public PizzaBuilder() {
    this.crust = null;
    this.size = null;
    this.toppings = new HashMap<ToppingName, ToppingPortion>();
  }

  public PizzaBuilder crust(Crust crust) {
    this.crust = crust;
    return returnBuilder();
  }

  public PizzaBuilder size(Size size) {
    this.size = size;
    return returnBuilder();
  }

  public PizzaBuilder addTopping(ToppingName toppingName, ToppingPortion toppingPortion) {
    this.toppings.put(toppingName, toppingPortion);
    return returnBuilder();
  }

  public abstract ObservablePizza build() throws IllegalStateException;

  protected abstract PizzaBuilder<T> returnBuilder();

  public abstract ObservablePizza noCheese();

  public abstract ObservablePizza leftHalfCheese();

  public abstract ObservablePizza rightHalfCheese();

  public abstract ObservablePizza noJalapeno();

}
