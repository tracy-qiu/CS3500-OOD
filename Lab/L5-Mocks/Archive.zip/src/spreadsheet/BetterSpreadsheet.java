package spreadsheet;

public class BetterSpreadsheet {

}
