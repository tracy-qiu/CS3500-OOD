package spreadsheet;

/**
 * BetterSpreadsheet class that extends the Spreadsheet class.
 */
public class BetterSpreadsheet {

}
