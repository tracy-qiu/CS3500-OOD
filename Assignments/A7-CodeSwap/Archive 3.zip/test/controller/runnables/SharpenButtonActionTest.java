package controller.runnables;

/**
 * The test for Sharpen Button.
 */
public class SharpenButtonActionTest extends AbstractButtonActionTest {

  /**
   * Constructs a button test.
   */
  public SharpenButtonActionTest() {
    super("Sharpen Button",
            "added listeners\nCommand: asked: Name the modified version of the image:\n");
  }
}