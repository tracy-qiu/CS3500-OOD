package view;

import org.junit.Test;

import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;
import cs3500.marblesolitaire.view.TriangleSolitaireTextView;

import static org.junit.Assert.assertEquals;

public class TriangleSolitaireTextViewTest {
  MarbleSolitaireView triangleModel1 = new TriangleSolitaireTextView(new TriangleSolitaireModel());

  MarbleSolitaireView triangleModel2 = new TriangleSolitaireTextView(new TriangleSolitaireModel(6));
  MarbleSolitaireView triangleModel3 = new TriangleSolitaireTextView(new TriangleSolitaireModel(2, 1));
  MarbleSolitaireView triangleModel4 = new TriangleSolitaireTextView(new TriangleSolitaireModel(7,6,3 ));


  @Test
  public void testToString() {
    assertEquals("    _\n"
            + "   O O\n"
            + "  O O O\n"
            + " O O O O\n"
            + "O O O O O", triangleModel1.toString());
    assertEquals("     _\n"
            + "    O O\n"
            + "   O O O\n"
            + "  O O O O\n"
            + " O O O O O\n"
            + "O O O O O O", triangleModel2.toString());
    assertEquals("    O\n"
            + "   O O\n"
            + "  O _ O\n"
            + " O O O O\n"
            + "O O O O O", triangleModel3.toString());
    assertEquals("      O\n"
            + "     O O\n"
            + "    O O O\n"
            + "   O O O O\n"
            + "  O O O O O\n"
            + " O O O O O O\n"
            + "O O O _ O O O", triangleModel4.toString());
  }
}
