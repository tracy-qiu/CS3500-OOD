package cs3500.marblesolitaire;

import java.io.InputStreamReader;
import java.io.StringReader;

import cs3500.marblesolitaire.controller.MarbleSolitaireController;
import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

public final class MarbleSolitaire {
  public static void main(String[] args) {
    MarbleSolitaireModel model = new EuropeanSolitaireModel(0, 5);
    Readable userInput = new InputStreamReader(System.in);
    Appendable controllerOutput = System.out;
    MarbleSolitaireView view = new MarbleSolitaireTextView(model, controllerOutput);
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(model, view,
            userInput);
    controller.playGame();
  }
}
