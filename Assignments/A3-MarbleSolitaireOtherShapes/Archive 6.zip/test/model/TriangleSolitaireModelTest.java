package model;

/**
 * Test class for triangle solitaire model, testing its methods and constructors.
 */
public class TriangleSolitaireModelTest {

}
