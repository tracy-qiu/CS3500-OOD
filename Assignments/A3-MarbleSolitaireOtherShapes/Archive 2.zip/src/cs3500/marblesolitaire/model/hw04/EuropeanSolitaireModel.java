package cs3500.marblesolitaire.model.hw04;

public class EuropeanSolitaireModel extends AbstractSolitaireModel {

  /**
   * English solitaire model constructor that creates default board with arm thickness 3, and empty
   * cell at (3.3).
   */
  public EuropeanSolitaireModel() {
    super(3, 3, 3);
    this.boardState = this.initializeBoard();
  }

  /**
   * English solitaire model constructor that creates board with arm thickness 3, and empty
   * cell at specified (sRow, sCol) position.
   *
   * @param sRow row coordinate of empty slot
   * @param sCol row coordinate of empty slot
   * @throws IllegalArgumentException if invalid cell position
   */
  public EuropeanSolitaireModel(int sRow, int sCol) throws IllegalArgumentException {
    super(3, sRow, sCol);
    int center = this.getBoardSize() / 2;
    int margin = this.armThickness / 2;
    if (!((sRow >= center - margin && sRow <= center + margin && sCol >= 0
            && sCol < this.getBoardSize())
            || (sCol >= center - margin && sCol <= center + margin && sRow >= 0
            && sRow < this.getBoardSize()))) {
      throw new IllegalArgumentException(String.format("Invalid cell position " + "%d " + "%d",
              sRow, sCol));
    }
    this.sRow = sRow;
    this.sCol = sCol;
    this.boardState = this.initializeBoard();
  }

  /**
   * English solitaire model constructor that creates board with specified arm thickness, and empty
   * cell at (3, 3) position.
   *
   * @param armThickness number of marbles in the top row
   * @throws IllegalArgumentException if invalid arm thickness
   */
  public EuropeanSolitaireModel(int armThickness) throws IllegalArgumentException {
    super(armThickness, (3 * armThickness - 2) / 2, (3 * armThickness - 2) / 2);
    if (armThickness % 2 == 0) {
      throw new IllegalArgumentException(String.format("Invalid arm thickness " + "%d:",
              armThickness));
    }
    this.armThickness = armThickness;
    this.boardState = this.initializeBoard();
  }

  /**
   * English solitaire model constructor that creates board with specified arm thickness, and empty
   * cell at specified (sRow, sCol) position.
   *
   * @param armThickness number of marbles in the top row
   * @param sRow         row coordinate of empty slot
   * @param sCol         col coordinate of empty slot
   * @throws IllegalArgumentException if invalid cell position and invalid arm thickness.
   */
  public EuropeanSolitaireModel(int armThickness, int sRow, int sCol)
          throws IllegalArgumentException {
    super(armThickness, sRow, sCol);
    if (armThickness % 2 == 0) {
      throw new IllegalArgumentException(String.format("Invalid even arm thickness " + "%d:",
              armThickness));
    }
    this.armThickness = armThickness;

    int center = this.getBoardSize() / 2;
    int margin = this.armThickness / 2;
    if (sRow < 0 || sCol < 0 || sRow > this.getBoardSize() - 1 || sCol > this.getBoardSize() - 1) {
      throw new IllegalArgumentException(String.format("Invalid out of bounds cell position "
                      + "%d " + "%d", sRow, sCol));
    }
    if (sRow < armThickness && sCol < armThickness - 1 && sRow + sCol < armThickness - 1
            || sRow < armThickness && sCol >= 2*armThickness - 1 && sCol < this.getBoardSize() &&
            this.getBoardSize() - sRow + sCol < armThickness
            || sRow >= 2*armThickness - 1 && sRow < this.getBoardSize() & sCol < armThickness - 1 &&
            this.getBoardSize() - sRow + sCol < armThickness
            || sRow >= 2*armThickness - 1 && sRow < this.getBoardSize() &&
            sCol >= 2*armThickness - 1 && sCol < this.getBoardSize() &&
            2 * this.getBoardSize() - sCol - sRow <= armThickness) {
      throw new IllegalArgumentException(String.format("Invalid cell position "
              + "%d " + "%d", sRow, sCol));
    }
    this.sRow = sRow;
    this.sCol = sCol;
    this.boardState = this.initializeBoard();
  }

  @Override
  protected SlotState[][] initializeBoard() {
    SlotState[][] newBoard = new SlotState[this.getBoardSize()][this.getBoardSize()];
    for (int row = 0; row < this.getBoardSize(); row++) {
      for (int col = 0; col < this.getBoardSize(); col++) {
        newBoard[row][col]= SlotState.Marble;
      }
    }
    newBoard[sRow][sCol] = SlotState.Empty;
    // top rows
    for (int row = 0; row < armThickness - 1; row++){
      // top left
      for (int col = 0; col < armThickness - 1; col++) {
        if (row + col < armThickness - 1) {
          newBoard[row][col] = SlotState.Invalid;
        }
      }
      //top right
      for (int col = 2*armThickness - 1; col < this.getBoardSize(); col++) {
        if (this.getBoardSize() - col + row < armThickness) {
          newBoard[row][col] = SlotState.Invalid;
        }
      }
    }
    // bottom rows
    for (int row = 2*armThickness - 1; row < this.getBoardSize(); row++){
      // bottom left
      for (int col = 0; col < armThickness - 1; col++) {
        if (this.getBoardSize() - row + col < armThickness) {
          newBoard[row][col] = SlotState.Invalid;
        }
      }
      // bottom right
      for (int col = 2*armThickness - 1; col < this.getBoardSize(); col++) {
        if (2 * this.getBoardSize() - col - row <= armThickness) {
          newBoard[row][col] = SlotState.Invalid;
        }
      }
    }
    return newBoard;
  }
}
