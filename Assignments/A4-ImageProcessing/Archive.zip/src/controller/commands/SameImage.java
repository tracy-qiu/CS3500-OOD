package controller.commands;

import java.io.IOException;

import controller.ImageCommand;
import model.ImageModel;

public class SameImage implements ImageCommand {
  @Override
  public void goCommand(ImageModel model) throws IllegalArgumentException, IOException {

  }
}
